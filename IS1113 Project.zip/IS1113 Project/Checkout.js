const Hyperautomation = 200;
const discountRate = 0.05;
const vatRate = 0.2;

let totalPrice = Hyperautomation - (Hyperautomation * discountRate) + (Hyperautomation * vatRate);
totalPrice.toFixed(2);

console.log("Total:", totalPrice);

