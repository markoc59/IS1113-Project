$('#scroller').imageScroll({

 

  // top,right,bottom,left optional

  orientation:"left",

 

  // animation speed

  speed:600,

 

  // animation interval

  interval:1500,

 

  // pause on hover

  hoverPause:true,

 

  // callback function after every scroll motion

  callback:function(){return false;}

 

});
